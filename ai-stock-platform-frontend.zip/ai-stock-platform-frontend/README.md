
# AI Stock Prediction Platform Frontend

Tech Stack:
- Next.js
- React
- Tailwind CSS
- TypeScript

## Pages
- Landing Page
- Dashboard
- AI Predictions
- Watchlist

## Run
```bash
npm install
npm run dev
```
