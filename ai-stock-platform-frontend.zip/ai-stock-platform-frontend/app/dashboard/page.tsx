
export default function DashboardPage() {
  return (
    <main style={{padding: "40px", fontFamily: "Arial"}}>
      <h1>Dashboard</h1>

      <div style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: "20px",
        marginTop: "20px"
      }}>
        <div style={{
          border: "1px solid #ccc",
          padding: "20px",
          borderRadius: "10px"
        }}>
          <h2>AI Prediction</h2>
          <p>Stock: AAPL</p>
          <p>Prediction: Bullish</p>
          <p>Confidence: 87%</p>
        </div>

        <div style={{
          border: "1px solid #ccc",
          padding: "20px",
          borderRadius: "10px"
        }}>
          <h2>Watchlist</h2>
          <ul>
            <li>TSLA</li>
            <li>NVDA</li>
            <li>AMZN</li>
          </ul>
        </div>
      </div>
    </main>
  );
}
