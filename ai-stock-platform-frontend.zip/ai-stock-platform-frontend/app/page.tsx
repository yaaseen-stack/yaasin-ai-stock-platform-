
export default function HomePage() {
  return (
    <main style={{padding: "40px", fontFamily: "Arial"}}>
      <h1>AI Stock Prediction Platform</h1>
      <p>Professional AI-powered stock analytics dashboard.</p>

      <div style={{
        marginTop: "30px",
        padding: "20px",
        border: "1px solid #ccc",
        borderRadius: "10px"
      }}>
        <h2>Features</h2>
        <ul>
          <li>AI Predictions</li>
          <li>Stock Watchlists</li>
          <li>Market News</li>
          <li>Technical Indicators</li>
        </ul>
      </div>
    </main>
  );
}
